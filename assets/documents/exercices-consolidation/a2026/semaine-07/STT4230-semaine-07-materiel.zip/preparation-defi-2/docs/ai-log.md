# Déclaration d’utilisation de l’IA, défi technique 2

Nom : à compléter
IDUL : à compléter
Sigle : à compléter
Date : à compléter

## 1. Usage ou non-usage de l’IA

Indiquer si vous avez utilisé une IA. Si oui, nommer les outils, les dates et les usages. Indiquer le modèle seulement s’il est affiché; sinon, écrire « modèle non affiché ». Mentionner aussi les autres ressources consultées.

Si une aide d’IA reçue avant la séance a servi dans votre travail, la déclarer ici.

À compléter.

## 2. Contributions significatives, si vous avez utilisé l’IA

Décrire une à trois contributions. Pour chacune, préciser le passage concerné, ce que l’outil a proposé, votre décision et la vérification effectuée avec son résultat. Une ligne peut suffire par contribution; un résumé fidèle suffit. Ne pas inventer d’interactions.

Sans IA, écrire « Sans objet ».

À compléter.

## 3. Décision personnelle et attestation, pour tous

Expliquer une décision personnelle liée à un passage précis du travail et indiquer comment vous l’avez vérifiée.

À compléter.

Attester avec vos mots que cette déclaration décrit les aides réellement reçues.

À compléter.
