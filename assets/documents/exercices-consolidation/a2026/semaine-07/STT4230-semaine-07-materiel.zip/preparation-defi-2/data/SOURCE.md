# Source des données

Taux : ministère des Finances du Canada, [liste des produits américains assujettis aux contre-mesures](https://www.canada.ca/fr/ministere-finances/programmes/politiques-finances-echanges-internationaux/reponse-canada-droits-douane-americains/liste-complete-produits-americains-assujettis-contre-mesures-tarifaires.html), données préparées par [Données bleues](https://donneesbleues.ca/datasets/tarifs-douaniers-quebec/fiche.html).

Le fichier `observations_contre_tarifs.csv` contient trois tableaux historiques correspondant à des périodes différentes. Il est conservé sans modification. Les informations fournies ne résolvent pas toutes les conditions d'application des droits et ne constituent pas une facture douanière réelle.

`lots_essai.csv` et `scenarios_essai.csv` sont des exemples fictifs créés pour comprendre les colonnes et vérifier la lecture des fichiers. Les libellés sont simplifiés; les codes servent de références documentaires et ne constituent pas un classement douanier. Les deux scénarios comparent la même commande au 20 août 2025 (avant) et au 10 septembre 2025 (après). Les valeurs, identifiants et paramètres d'essai ne sont pas ceux de l'épreuve.

Les fichiers `lots_importation.csv` et `scenarios.csv`, à analyser pendant le défi, seront fournis séparément à 13 h 30.

Conditions de réutilisation : `DATA_LICENSE.md`.
