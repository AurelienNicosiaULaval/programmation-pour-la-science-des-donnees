# Attribution et droits

Les taux proviennent du ministère des Finances du Canada et sont distribués dans le jeu de [Données bleues](https://donneesbleues.ca/datasets/tarifs-douaniers-quebec/fiche.html). Les informations fédérales conservent les [conditions de reproduction de leur source](https://www.canada.ca/fr/transparence/avis.html).

La documentation originale de Données bleues est sous CC BY 4.0, avec attribution à Données bleues. Cette licence ne remplace pas les conditions du producteur des taux.

Les lots d'essai, leurs valeurs et le scénario d'essai sont des données fictives créées pour la prise en main pédagogique.
